require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const cors = require('cors');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const apicache = require('apicache');
const crypto = require('crypto');
const xss = require('xss');
const rfs = require('rotating-file-stream');

const app = express();
const PORT = 3000;

// ===== GLOBAL DATA =====
const messages = [];
const lastMessage = {};
const cache = apicache.middleware;

// ===== BASIC SECURITY =====
app.disable('x-powered-by');

app.use((req, res, next) => {
  req.id = crypto.randomUUID();
  res.setHeader('X-Request-ID', req.id);
  next();
});

app.use(compression());

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      objectSrc: ["'none'"]
    }
  },
  referrerPolicy: { policy: "no-referrer" }
}));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  next();
});

// ===== BODY PARSER =====
app.use(express.urlencoded({ extended: true, limit: '5kb' }));
app.use(express.json({ limit: '5kb' }));

// ===== CORS =====
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || origin === process.env.CLIENT_URL) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed'));
    }
  }
}));

// ===== RATE LIMIT =====
app.use('/api', rateLimit({
  windowMs: 60 * 1000,
  max: 20
}));

// ===== SLOW DOWN =====
const speedLimiter = slowDown({
  windowMs: 60 * 1000,
  delayAfter: 50,
  delayMs: () => 500
});
app.use('/api', speedLimiter);

// ===== API KEY =====
app.use('/api', (req, res, next) => {
  const key = req.headers['x-api-key'];

  if (!key || key !== process.env.API_KEY) {
    return res.status(403).json({ error: 'Invalid API key' });
  }

  next();
});

// ===== CONTENT TYPE CHECK =====
app.use('/api', (req, res, next) => {
  const contentType = req.headers['content-type'] || '';

  if (req.method !== 'GET' && !contentType.includes('application/json')) {
    return res.status(415).json({ error: 'Invalid content type' });
  }

  next();
});

// ===== SPAM PROTECTION =====
app.post('/api/v1/messages', (req, res, next) => {
  const ip = req.ip;

  if (lastMessage[ip] && Date.now() - lastMessage[ip] < 3000) {
    return res.status(429).json({ error: 'spam detected' });
  }

  lastMessage[ip] = Date.now();
  next();
});

// ===== LOGGING =====
const accessLogStream = rfs.createStream('access.log', {
  interval: '1d',
  maxFiles: 7
});

app.use(morgan('combined', {
  stream: accessLogStream,
  skip: (req, res) => res.statusCode < 400
}));

app.use((req, res, next) => {
  res.on('finish', () => {
    if (res.statusCode >= 400) {
      console.log(`[ERROR] ${req.ip} ${req.method} ${req.url}`);
    }
  });
  next();
});

// ===== ROUTES =====

// POST message
app.post('/api/v1/messages', (req, res) => {
  let { text, icon, color, effect } = req.body;

  const allowedFields = ['text', 'icon', 'color', 'effect'];
  const keys = Object.keys(req.body);

  for (let key of keys) {
    if (!allowedFields.includes(key)) {
      return res.status(400).json({ error: 'Invalid field' });
    }
  }

  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Invalid text' });
  }

  text = xss(text.trim());

  if (text.length < 1 || text.length > 100) {
    return res.status(400).json({ error: 'Invalid text length' });
  }

  if (JSON.stringify(req.body).length > 1000) {
    return res.status(413).json({ error: 'Payload too large' });
  }

  icon = typeof icon === 'string' ? xss(icon) : '✔️';
  color = typeof color === 'string' ? color : '#ffffff';
  effect = typeof effect === 'string' ? effect : 'none';

  const newMsg = {
    text,
    icon,
    color,
    effect,
    createdAt: new Date()
  };

  messages.push(newMsg);

  res.json({
    success: true,
    data: newMsg,
    requestId: req.id
  });
});

// GET all
app.get('/api/v1/messages', cache('1 minute'), (req, res) => {
  res.json({
    status: "OK",
    serverTime: Date.now(),
    result: messages,
    requestId: req.id
  });
});

// RANDOM
app.get('/api/v1/messages/random', (req, res) => {
  if (messages.length === 0) {
    return res.status(404).json({ error: 'No messages' });
  }

  const random = messages[Math.floor(Math.random() * messages.length)];

  res.json({
    success: true,
    data: random,
    requestId: req.id
  });
});

// FILTER
app.get('/api/v1/messages/filter', (req, res) => {
  const { color } = req.query;

  const filtered = messages.filter(m => m.color === color);

  res.json({
    success: true,
    data: filtered
  });
});

// ===== ERROR HANDLER =====
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'something went wrong' });
});

// ===== SHUTDOWN =====
const server = app.listen(PORT, () => {
  console.log(`http://localhost:${PORT}`);
});

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

function shutdown() {
  console.log('shutting down...');
  server.close(() => {
    process.exit(0);
  });
}