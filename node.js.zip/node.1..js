require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const cors = require('cors');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const apicache = require('apicache');
const crypto = require('crypto');
const xss = require('xss');
const rfs = require('rotating-file-stream');

const app = express();
const PORT = process.env.PORT || 3000;

// ===== MEMORY STORE (dev only) =====
const messages = [];
const lastMessage = {};
const cache = apicache.middleware;

// ===== TRUST PROXY (deploy VPS / nginx) =====
app.set('trust proxy', 1);

// ===== REQUEST ID =====
app.use((req, res, next) => {
  req.id = crypto.randomUUID();
  res.setHeader('X-Request-ID', req.id);
  next();
});

// ===== SECURITY =====
app.disable('x-powered-by');

app.use(helmet({
  contentSecurityPolicy: false, // API không cần CSP cứng
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));

app.use(compression());

// ===== BODY =====
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// ===== CORS (multi domain) =====
const allowedOrigins = [process.env.CLIENT_URL];

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    return cb(new Error('CORS blocked'));
  }
}));

// ===== RATE LIMIT GLOBAL =====
app.use('/api', rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false
}));

// ===== SLOW DOWN =====
app.use('/api', slowDown({
  windowMs: 60 * 1000,
  delayAfter: 30,
  delayMs: () => 300
}));

// ===== API KEY =====
app.use('/api', (req, res, next) => {
  const key = req.headers['x-api-key'];
  if (!key || key !== process.env.API_KEY) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  next();
});

// ===== CONTENT-TYPE =====
app.use('/api', (req, res, next) => {
  const ct = req.headers['content-type'] || '';
  if (req.method !== 'GET' && !ct.includes('application/json')) {
    return res.status(415).json({ error: 'Invalid content type' });
  }
  next();
});

// ===== SPAM =====
app.post('/api/v1/messages', (req, res, next) => {
  const ip = req.ip;
  if (lastMessage[ip] && Date.now() - lastMessage[ip] < 2000) {
    return res.status(429).json({ error: 'Too fast' });
  }
  lastMessage[ip] = Date.now();
  next();
});

// ===== LOGGER =====
const logStream = rfs.createStream('access.log', {
  interval: '1d',
  maxFiles: 7
});

app.use(morgan('combined', {
  stream: logStream
}));

// ===== ROUTES =====

// POST
app.post('/api/v1/messages', (req, res) => {
  let { text, icon, color, effect } = req.body;

  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Invalid text' });
  }

  text = xss(text.trim());

  if (text.length < 1 || text.length > 200) {
    return res.status(400).json({ error: 'Invalid length' });
  }

  icon = typeof icon === 'string' ? xss(icon) : '✔️';
  color = typeof color === 'string' ? color : '#fff';
  effect = typeof effect === 'string' ? effect : 'none';

  const msg = {
    id: crypto.randomUUID(),
    text,
    icon,
    color,
    effect,
    createdAt: Date.now()
  };

  messages.push(msg);

  res.status(201).json({
    success: true,
    data: msg,
    requestId: req.id
  });
});

// GET ALL (cache)
app.get('/api/v1/messages', cache('30 seconds'), (req, res) => {
  res.json({
    count: messages.length,
    data: messages
  });
});

// RANDOM
app.get('/api/v1/messages/random', (req, res) => {
  if (!messages.length) {
    return res.status(404).json({ error: 'Empty' });
  }

  const msg = messages[Math.floor(Math.random() * messages.length)];

  res.json({ data: msg });
});

// FILTER
app.get('/api/v1/messages/filter', (req, res) => {
  const { color } = req.query;

  const filtered = messages.filter(m => m.color === color);

  res.json({ data: filtered });
});

// HEALTH CHECK (rất quan trọng production)
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    uptime: process.uptime(),
    time: Date.now()
  });
});

// ===== ERROR =====
app.use((err, req, res, next) => {
  console.error(`[${req.id}]`, err.message);
  res.status(500).json({ error: 'Internal Server Error' });
});

// ===== START =====
const server = app.listen(PORT, () => {
  console.log(`🚀 http://localhost:${PORT}`);
});

// ===== SHUTDOWN =====
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

function shutdown() {
  console.log('Shutting down...');
  server.close(() => process.exit(0));
}