/// ====== tìm tuần tự ====== ///

function linearSearch(arr: number[],target: number):number
{
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] === target) return i;
  }
  return -1;
}

/// === tìm nhanh mảng đã sort === ///

function binarySearch(arr: number[],target: number): number {
  let left = 0;
  let right = arr.length - 1;
  
  while (left <= right) {
    const mid = Math.floor((left + right) /2);
    
    if (arr[mid] === target) return mid;
    if (arr[mid] < target) left = mid + 1;
     else right = mid - 1;
  }
  
  return -1;
}

/// ==== sắp xếp ==== ///

function quickSort(arr: number[]):
number[] {
  if (arr.length <= 1) return arr;
  
  const pivot = arr[Math.floor(arr.length / 2)];
  const left = arr.filter(x => x < pivot);
  const right = arr.filter(x => x > pivot);
  const middle = arr.filter(x => x === pivot);
  
 return [...quickSort(left), ...middle, ...quickSort(right)];
}

const sorted = [5, 4, 2, 1].sort((a,b) => a - b);

/// ==== Lọc dữ liệu ==== ///

type UserFull = {
  id: number;
  name: string;
  age: number;
};

const users: UserFull[] = [
  { id: 1, name: "A", age: 18 },
  { id: 2, name: "B", age: 20 }
];

const adults = users.filter(u => u.age >= 18);

function removeDuplicates(arr: number[]): number[] {
  return [...new Set(arr)];
}

type UserBasic = { id: number; name: string };

function uniqueUsers(users: UserBasic[]): UserBasic[] {
  
  const map = new Map<number, UserBasic>();
  
  for (const user of users) {
    map.set(user.id, user);
  }
  
  return [...map.values()];
}

/// === tách trang === ///

function paginate<T>(data: T[], page: number, limit: number): T[]
{
  const start = (page - 1) * limit;
  const end = start + limit;
  
  return data.slice(start, end);
}

/// === Đếm tần suất === ///

function countFrequency(arr: string[]) {
  const freq: Record<string, number> = {};
 for (const item of arr) {
   freq[item] = (freq[item] || 0) + 1;
 }
 
 return freq; 
}


/// ==== gộp & xử lý dữ liệu === ///

// biến đổi dữ liệu 
const numbers = [2, 3, 4];

const doubled = numbers.map(x => x * 2);

// Tổng hợp dữ liệu 

const sum = numbers.reduce((acc, cur) => acc + cur, 0);

/// ==== tìm phân tử lớn nhất và nhỏ nhất ==== ///

const arr = [11, 5, 20, 6];

const max = Math.max(...arr);
const min = Math.min(...arr);

/// ===== Debounce ===== ///

function debounce<T extends (...args: any[]) => void>(fn: T, delay: number) {
  let timer: NodeJS.Timeout;
  
  return (...args: Parameters<T>) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

/// ==== giới hạn tần suất gọi APl ///

function throttle<T extends (...args: any[]) => void>(fn: T, limit: number) {
  let lastCall = 0;
  
  return (...args: Parameters<T>) => {
    const now = Date.now();
    if (now - lastCall >= limit) {
      lastCall = now;
      fn(...args);
    }
  };
} 

