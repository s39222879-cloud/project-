import mysql from "mysql2/promise";

export const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "appdb",
  waitForConnections: true,
  connectionLimit: 10
});

/// ======= JWT helper ===== ///

import jwt from "jsonwebtoken";

const SECRET = "secret_key";

export function signToken(payload: object) {
  return jwt.sign(payload, SECRET, 
  { expiresIn: "1h" });
}

export function verifyToken(token: string) {
  return jwt.verify(token, SECRET);
}

/// === hash password === ///

import bcrypt from "bcrypt";

export async function hashPassword(password: string) {
  return await bcrypt.hash(password ,10);
}

export async function 
comparePassword(password: string, hash: string) {
  return await bcrypt.compare(password, hash);
}

/// === auth service === ///

import { pool } from "../../db/pool";
import { hashPassword, comparePassword } from "../../utils/hash";
import { signToken } from "../../utils/jwt";

export class AuthService {
  
  static async register(username: string, password: string, age: number) {
  const hashed = await hashPassword(password);
  
  await pool.query(
    "insert into users (username, password_hash, age) values (?, ?, ?)",
    [username, hashed, age]
  );
  
  return { message: "registered" };
}

static async login(username: string, password: string) {
  const [rows]: any = await pool.query("select * from users where username = ?",
    [username]
  );
  
  if (rows.length === 0) throw new Error("User not found");
  
  const user = rows[0];
  
  const ok = await comparePassword(password, user.password_hash);
  if (!ok) throw new Error("Wrong password");
  
  const token = signToken({
    id: user.id,
    username: user.username
  });
  
  return { token };
 }
}

/// === controller (APl layer) ///

import { Request, Response } from "express";
import { AuthService } from "./auth.service";

export class AuthController {
  
  static async register(req: Request, res: Response) {
    try {
      const { username, password, age } = req.body;
      const result = await AuthService.register(username, password, age);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
  }
}

static async login(req: Request, res: Response) {
  try {
    const { username, password } = req.body;
    const result = await AuthService.login(username, password);
    res.json(result);
  } catch (err: any) {
    res.status(401).json({error: err.message });
  }
 }
}

/// ====== ROUTES ===== ///

import express from "express";
import { AuthController } from "./auth.controller";

const router = express.Router();

router.post("/register",
AuthController.register);
router.post("/login",
AuthController.login);

export default router;

/// === JWT Middleware (protect APl) ///

import { Request, Response, NextFunction }
from "express";
import { verifyToken } from "../utils/jwt";

export function authMiddleware(req: any, res: Response, next: NextFunction) {
  
  const token = req.headers.authorization;
  
  if (!token) return res.sendStatus(401);
  
  try {
    const decoded = verifyToken(token.replace("Bearer ", ""));
    req.user = decoded;
    next();
  } catch {
    return res.sendStatus(403);
  }
}

/// ===== App setup ===== ///

import express from "express";
import authRoutes from "./modules/auth/auth.routes";

const app = express();
app.use(express.json());

app.use("/auth", authRoutes);

export default app;

import app from "./app";

app.listen(3000, () => {
  console.log("server running http://localhost:3000");
});
